# Economic Commons

Contribution Area: Resource-sharing and value-exchange across diverse intelligences.

- Analogies: Commons-based peer production; ecological nutrient cycles.
- Open questions: How do we design commons that reward plurality without extractive dominance?
