# Governance

Principle: Stewardship and decision-making across diverse forms of intelligence.

- Analogies: Power-sharing agreements; rotating leadership in tribes.
- Open questions: How do we design governance that avoids privileging one architecture?
