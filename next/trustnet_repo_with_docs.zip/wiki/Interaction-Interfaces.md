# Interaction Interfaces

Contribution Area: Tools and methods for entities with different modalities to interact.

- Analogies: Human-computer interaction; language interpreters.
- Open questions: How do we create interfaces that do not erase difference but allow genuine communication?
