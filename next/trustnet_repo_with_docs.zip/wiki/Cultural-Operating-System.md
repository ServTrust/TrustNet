# Cultural Operating System

Contribution Area: Shared norms and symbolic systems that orient diverse natures.

- Analogies: Open-source community codes of conduct; cultural rituals.
- Open questions: What are the minimal cultural primitives needed for coherence without uniformity?
