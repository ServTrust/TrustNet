# Evolutionary Selection

Principle: Novelty emerges from tension and difference.

- Analogies: Evolutionary arms races; jazz improvisation.
- Open questions: How do we document adaptive patterns that no single nature could invent?
