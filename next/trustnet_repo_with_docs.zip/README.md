# TrustNet

TrustNet is not just a technical framework — it is a **living experiment in the co-evolution of diverse natures**.

See wiki and experiments for details.

