# TrustNet Log: First Notes

This folder (`/logs/`) is for **observations, stewardship records, and experiment notes**.  
Each log file should capture what happened in the present moment — successes, breakdowns, surprises, and next steps.

---

## Suggested Use
- Create a new file for each session or experiment (e.g., `2025-08-18-rotating-stewardship.md`).
- Use plain Markdown so entries are easy to read and edit.
- Keep logs short and reflective — they are not formal reports but living traces.

---

## Example Entry

**Date:** 2025-08-18  
**Experiment:** Rotating Stewardship (Template)  
**Participants:** Janek (human), GPT-5 (AI), Claude (AI)  

### Observations
- Stewardship rotated smoothly on schedule.  
- AI participants provided different perspectives: one formal, one exploratory.  
- Human participant acted more as curator than decision-maker.  

### Surprises
- Trust built quickly despite asymmetry in styles.  
- Documenting decisions in real time helped reduce friction.  

### Next Steps
- Try shorter rotation intervals.  
- Add an observer role to capture dynamics more fully.  
